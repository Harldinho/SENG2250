c3349828 - SENG2250 A3
Didnt manage to finish Q2 only implemented
the fast modular exponentation algorithm


Client.java
Server.java

in cmd type "javac Server.java"
then type "java Server"

this will run the server
to get the client to connect to the server type what is
above but change "Server" to "Client"